LSM Portfolio — Projects Showcase Edition
Open HTMLPage1.html in your browser. Keep all files together.
Project visuals are conceptual SVG illustrations, NOT actual screenshots.
The Palace Lodge live link opens the external website.
Graduate CV is included.
